#pragma once

#include "ofFileUtils.h"

#warning ofxDirList has been deprecated. 
#warning Remove all references to ofxDirList.h and use ofDirectory instead.
typedef ofDirectory ofxDirList;