#ifndef _OFX_NETWORK_
#define _OFX_NETWORK_

#include "ofxTCPClient.h"
#include "ofxTCPManager.h"
#include "ofxTCPServer.h"
#include "ofxUDPManager.h"

#endif



